﻿namespace GSMInfo
{
    public enum BatteryType
    {
        LiIon,
        NiMH,
        NiCd
    }
}
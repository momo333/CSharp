// Write a function to count the number of divs on the
// web page




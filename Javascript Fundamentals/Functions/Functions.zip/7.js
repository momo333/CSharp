// Write a function that returns the index of the first
// element in array that is bigger than its neighbors, or
// -1, if there’s no such element.

var array =[2,3,5,14,8,5,12,5,94,2,5];


function checkIfBigger(array){

	for (var i = 1; i < array.length-1; i++) {
		if(array[i]>array[i+1] && array[i]>array[i-1]){
			return i;
			break;
		} 	
	};
	return -1;
}

if(checkIfBigger(array)===-1){
	console.log("There is no such element!");
} else {
console.log("The element with index " + checkIfBigger(array));	
}


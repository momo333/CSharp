//Write a boolean expression that checks for given integer if it can be divided (without remainder) by 7 and 5 in the same time.

// var a = prompt('Enter number a: ');

var a = 35;

if(a%35===0){
  console.log('true');
}else{
   console.log('false');
}


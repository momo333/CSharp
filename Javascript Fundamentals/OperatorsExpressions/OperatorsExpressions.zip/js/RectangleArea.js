//Write an expression that calculates rectangle’s area by given width and height.

// var a = prompt('Enter width of the rectangle: ');
 // var b = prompt('Enter length of the rectangle: ');

var width=1;
var length=2;

console.log(calculateArea(width, length));

function calculateArea(width, length){
    return width * length;
}
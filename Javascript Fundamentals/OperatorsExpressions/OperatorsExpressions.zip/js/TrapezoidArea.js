//Write an expression that calculates trapezoid's area by given sides a and b and height h.


// var a = console.prompt("Enter value a");
// var b = console.prompt("Enter value b");
// var height = console.prompt("Enter value height");
var a = 2;
var b = 3;
var height = 4;

var area = ((a + b) / 2) * height;
console.log("The Trapezoid area is " + area);

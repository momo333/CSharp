// Write a script that converts a number in the range [0…999] to words, corresponding to its English pronunciation.

// var number = console.prompt("Enter number");
var number=123;

var ones = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"];
var tens = ["", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"];
var specialDigits = ["Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"];
var result="";
switch (number.length) {
                case 1: // 1-9
	                if (number[0] == 0) {
	                	result="Zero";
	                }
	                else {
	                	result=ones[number[0]];
	                }
                break;
                case 2: // 10 - 99
	                if (number[0] == 1) {
	                	result=specialDigits[number[1]];
	                }
	                else {
	                	result=tens[number[0]] + " " + ones[number[1]];
	                }
	                break;
	            case 3: // 100 - 999
	                if (number[1] == 1) {
	                	result=ones[number[0] + " hundred and " + specialDigits[number[2]]];
	                }
	                else {
	                	if (number[1] != 0 || number[2] != 0) {
	                		result=ones[number[0]] + " hundred and " + tens[number[1]] + " " + ones[number[2]];
	                	}
	                	else {
	                		result=ones[number[0]] + " hundred "   + tens[number[1]] + " " + ones[number[2]];
	                	}
	                }
                break;
                default:
                break;

            }
            console.log(result);

// Write a script that prints all the numbers from 1 to N.

// var number = console.prompt("Enter number");

var number = 30;

for(var i = 1; i <= number; i++){
    console.log(i);
}